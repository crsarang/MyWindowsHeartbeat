using System;
using Tamir.IPLib;
using Tamir.IPLib.Packets;
using Tamir.IPLib.Util;
using System.Collections;

namespace Test
{
	/// <summary>
	/// Basic capture example
	/// </summary>
	public class Class1
	{
		/// <summary>
		/// Basic capture example
		/// </summary>
		[STAThread]
		public static void Main(string[] args)
		{			
			//SendTcpSynExample.Main1(args);
			//UdpTest.Run(args);
		}
	}
}
